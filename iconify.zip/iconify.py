# i guess i restarted everything cuz i
# learned a new way to code this app
from PyQt5.QtWidgets import QMainWindow, QApplication
from PyQt5.QtGui import QIcon
from PyQt5 import uic
import emoji
import clipboard
import random
import requests

lookalikes = requests.get("https://gist.githubusercontent.com/StevenACoffman/a5f6f682d94e38ed804182dc2693ed4b/raw/fa2ed09ab6f9b515ab430692b588540748412f5f/some_homoglyphs.json").json()
leet_dict = {
    'A': '4', 'a': '4', 'B': '8', 'b': '8', 'E': '3', 'e': '3', 'G': '6', 'g': '6', 'I': '1', 'i': '1',
    'O': '0', 'o': '0', 'S': '5', 's': '5', 'T': '7', 't': '7', 'Z': '2', 'z': '2',
    'C': '(', 'c': '(', 'D': '|)', 'd': '|)', 'F': '|=', 'f': '|=', 'H': '#', 'h': '#', 'K': '|<', 'k': '|<',
    'L': '1', 'l': '1', 'M': '|\\/|', 'm': '|\\/|', 'N': '|\\|', 'n': '|\\|', 'P': '|*', 'p': '|*', 'Q': '(,)',
    'q': '(,)', 'R': '|2', 'r': '|2', 'U': '|_|', 'u': '|_|', 'V': '\\/', 'v': '\\/', 'W': '\\/\\/', 'w': '\\/\\/',
    'X': '><', 'x': '><', 'Y': '`/', 'y': '`/'
}


class iconifierWindow(QMainWindow):
    def __init__(self):
        super(iconifierWindow, self).__init__()
        uic.loadUi("assets/SOURCE.ui", self)
        iconifierWindow.setFixedSize(self, 302, 294)
        iconifierWindow.setWindowIcon(self, QIcon("assets/icon.png"))
        self.show()

        self.generate.clicked.connect(self.iconify)
        self.randomStyle.stateChanged.connect(self.usesRandomStyling)
        self.randomStyle_2.stateChanged.connect(self.usesRandomTextStyling)
        self.randomIcon.stateChanged.connect(self.usesRandomIcon)
        self.copy.clicked.connect(self.copyResult)
        self.clear.clicked.connect(self.clearResult)

    def iconify(self):
        emojized = emoji.emojize(f":{self.emoji.text()}:", variant="emoji_type")
        possibleStyles = ["「」", "〘〙", "  "]
        possibleIcons = list(emoji.EMOJI_DATA.keys())
        selectedStyle = random.choice(possibleStyles)
        selectedIcon = random.choice(possibleIcons)
        selected = self.styling.currentText()
        if self.randomStyle_2.isChecked():
            selectedTextStyle = random.choice(["Normal", "L33t", "Lookalike"])
        else:
            selectedTextStyle = self.textStyling.currentText()
        currentText = ""
        if selectedTextStyle == "Normal":
            currentText = self.text.text()
        elif selectedTextStyle == "Lookalike":
            for letter in self.text.text():
                try:
                    currentText = currentText + random.choice(lookalikes.get(letter.lower()))
                except:
                    currentText = currentText + letter
        elif selectedTextStyle == "L33t":
            for char in self.text.text():
                if char in leet_dict:
                    currentText += leet_dict[char]
                else:
                    currentText += char
        if not self.randomStyle.isChecked():
            if selected == "(none)":
                if not self.randomIcon.isChecked():
                    self.result.setText(f"{emojized} {currentText}")
                else:
                    self.result.setText(f"{selectedIcon} {currentText}")
            else:
                if not self.randomIcon.isChecked():
                    self.result.setText(f"{selected[0]}{emojized}{selected[1]} {currentText}")
                else:
                    self.result.setText(f"{selected[0]}{selectedIcon}{selected[1]} {currentText}")
        else:
            if not self.randomIcon.isChecked():
                self.result.setText(f"{selectedStyle[0]}{emojized}{selectedStyle[1]} {currentText}")
            else:
                self.result.setText(f"{selectedStyle[0]}{selectedIcon}{selectedStyle[1]} {currentText}")

    def usesRandomStyling(self, checked):
        self.styling.setEnabled(not checked)

    def usesRandomTextStyling(self, checked):
        self.textStyling.setEnabled(not checked)

    def usesRandomIcon(self, checked):
        self.emoji.setEnabled(not checked)

    def copyResult(self):
        clipboard.copy(self.result.text())
        message_box = QMessageBox()
        message_box.setIcon(QMessageBox.Information)
        message_box.setWindowTitle("Success")
        message_box.setText("Copied to clipboard! Made by Cheesehead.")
        message_box.setStandardButtons(QMessageBox.Ok)
        message_box.exec_()

    def clearResult(self):
        self.result.clear()


app = QApplication([])
window = iconifierWindow()
app.exec_()